<?php include_once 'header.php'; ?>
	<!--Page Title-->
    <section class="page-title" style="background-image: url(images/background/4.jpeg);">
    	<div class="auto-container">
        	<h1>الدفع</h1>
        	<ul class="bread-crumb">
                <li><a href="">الرئيسية</a></li>
                <li class="active">الدفع</li>
            </ul>
        </div>
    </section>