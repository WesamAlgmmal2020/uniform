<?php include_once 'header.php'; ?>


	<!--Two Default Section-->
    <section class="about-section">
        <div class="auto-container">
            
            <div class="row clearfix">

                    <div class="about-column column col-md-12 col-sm-12 col-xs-12">
                      <div class="inner">
                          <h2 style="margin-bottom: 3em" class="title text-primary text-center"><?=$_localize['body_measurements_heading'][$_SESSION['lang']]?></h2>
                      </div>

                      <figure class="image text-center">
                              <img src="images/body-content.png" alt="" style="width:400px">
                      </figure>
                      <figure class="image text-center">
                              <img src="images/clothing-measurement.png" alt="">
                      </figure>
                      
                    </div>

                </div>
            </div>
            
            
        </div>
        
    </div>
</section>
    <!--End Two Default Section-->


	
  <?php include_once 'footer.php'; ?>
