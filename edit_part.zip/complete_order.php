<?php include_once 'header.php'; ?>

<div class="complete-order-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="completePage-txt">
                    <h3> سيتم التواصل معكم في خلال 24 ساعة </h3>
                    <div class="end-order clearfix">
                        <button type="button" class="theme-btn btn-style-one"> حفظ </button>
                        <button onclick="window.print()" type="button" class="theme-btn btn-style-one"> طباعة </button>
                        <a href="index.php" type="button" class="theme-btn btn-style-one"> إنهــاء  </a>
                    </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'footer.php'; ?>