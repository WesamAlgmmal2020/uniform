<!--Main Footer-->
            <footer class="main-footer" style="padding-top:0px">
                <!--Footer Bottom-->
                <div class="footer-bottom">
                    <div class="copyright">&copy; 2022 </div>
                </div>


            </footer>
            <!--End Main Footer-->

        </div>
        <!--End pagewrapper-->

        <!--Scroll to top-->
        <div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="fa fa-long-arrow-up"></span></div>


        
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/revolution.min.js"></script>
        <script src="js/jquery.fancybox.pack.js"></script>
        <script src="js/jquery.fancybox-media.js"></script>
        <script src="js/owl.js"></script>
        <script src="js/wow.js"></script>
        <script src="js/isotope.js"></script>
        <script src="js/validate.js"></script>
        <script src="js/parallax.js"></script>
        <script src="js/jquery.bootstrap-touchspin.js"></script>
        <script src="js/script.js"></script>
        
    </body>

</html>
