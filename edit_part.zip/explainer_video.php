<?php include_once 'header.php'; ?>


	<!--Two Default Section-->
    <section class="about-section">
        <div class="auto-container">
            
            <div class="row clearfix">

            <div class="about-column column col-md-12 col-sm-12 col-xs-12">
                    <div class="inner">
                      <h2 style="margin-bottom: 3em" class="title text-primary text-center">
                        <?=$_localize['explainer_video_heading'][$_SESSION['lang']]?>
                      </h2>
                    </div>
                    <div style="text-align:center;">
                        <iframe width="560" height="355" src="https://www.youtube.com/embed/E4R4WuMDLAQ" title="YouTube video player" frameborder="0" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!--End Two Default Section-->


	
  <?php include_once 'footer.php'; ?>
